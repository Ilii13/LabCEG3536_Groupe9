Core/Src/motor.o: ../Core/Src/motor.s ../Core/Src/registres.inc \
 ../Core/Src/registres_lab2.inc
../Core/Src/registres.inc:
../Core/Src/registres_lab2.inc:
