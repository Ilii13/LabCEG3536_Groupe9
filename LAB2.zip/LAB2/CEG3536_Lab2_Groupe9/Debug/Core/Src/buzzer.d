Core/Src/buzzer.o: ../Core/Src/buzzer.s ../Core/Src/registres.inc \
 ../Core/Src/registres_lab2.inc
../Core/Src/registres.inc:
../Core/Src/registres_lab2.inc:
