Core/Src/systick.o: ../Core/Src/systick.s ../Core/Src/registres.inc \
 ../Core/Src/registres_lab2.inc
../Core/Src/registres.inc:
../Core/Src/registres_lab2.inc:
